"""
**Abstract validator (validation of input values)**

Imports
"""

from .aval import *
